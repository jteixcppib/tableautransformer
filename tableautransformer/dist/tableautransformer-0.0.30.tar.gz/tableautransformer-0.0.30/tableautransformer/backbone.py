# This module is used to restructure data in the shape of any desired graphical output in Tableau


def sub_one(number):
    return number -1

def half(number):
    return number/2
